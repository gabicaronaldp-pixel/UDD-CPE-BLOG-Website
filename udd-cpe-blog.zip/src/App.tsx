import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  Settings, 
  Rss, 
  Bookmark, 
  TrendingUp, 
  Search, 
  Bell, 
  Menu, 
  X, 
  ChevronRight, 
  ArrowRight,
  MessageSquare,
  Share2,
  Heart,
  Eye,
  Plus,
  BarChart3,
  Edit3,
  Trash2,
  Image as ImageIcon,
  Tag,
  Calendar,
  Globe,
  Lock,
  CheckCircle2,
  Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { format } from 'date-fns';
import { cn, Post, Comment, Stats } from './types';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
      isScrolled ? "bg-background-dark/80 backdrop-blur-md border-slate-800 py-3" : "bg-transparent border-transparent py-5"
    )}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="bg-primary p-1.5 rounded-lg group-hover:rotate-12 transition-transform">
            <Rss className="text-white size-5" />
          </div>
          <span className="text-xl font-bold tracking-tight">UDD-CPE Blog</span>
        </Link>
        
        <nav className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-sm font-medium text-slate-300 hover:text-primary transition-colors">Home</Link>
          <Link to="/feed" className="text-sm font-medium text-slate-300 hover:text-primary transition-colors">Discovery</Link>
          <Link to="/admin" className="text-sm font-medium text-slate-300 hover:text-primary transition-colors">Admin</Link>
        </nav>

        <div className="flex items-center gap-4">
          <div className="hidden sm:flex relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 size-4" />
            <input 
              type="text" 
              placeholder="Search insights..." 
              className="bg-slate-800/50 border border-slate-700 rounded-full pl-10 pr-4 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 w-48 lg:w-64"
            />
          </div>
          <button className="p-2 text-slate-400 hover:text-white transition-colors relative">
            <Bell className="size-5" />
            <span className="absolute top-2 right-2 size-2 bg-primary rounded-full border-2 border-background-dark"></span>
          </button>
          <div className="size-9 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center overflow-hidden">
            <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
        </div>
      </div>
    </header>
  );
};

const Sidebar = () => {
  const location = useLocation();
  const navItems = [
    { icon: Rss, label: 'Feed', path: '/feed' },
    { icon: Bookmark, label: 'Bookmarks', path: '/bookmarks' },
    { icon: TrendingUp, label: 'Trending', path: '/trending' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <aside className="w-64 hidden lg:flex flex-col gap-8 border-r border-slate-800 p-6 sticky top-24 h-[calc(100vh-6rem)]">
      <div className="flex items-center gap-3 p-2">
        <div className="size-10 rounded-full border-2 border-primary overflow-hidden">
          <img src="https://picsum.photos/seed/alex/100/100" alt="Alex" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>
        <div>
          <h3 className="text-sm font-bold">Alex Rivers</h3>
          <p className="text-[10px] text-slate-500 uppercase tracking-wider">CPE Junior Member</p>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            to={item.path}
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all",
              location.pathname === item.path ? "bg-primary/10 text-primary" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"
            )}
          >
            <item.icon className="size-5" />
            <span className="text-sm font-medium">{item.label}</span>
          </Link>
        ))}
      </nav>

      <div className="mt-auto">
        <div className="bg-primary/5 border border-primary/10 rounded-2xl p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Learning Progress</span>
            <span className="text-xs font-bold text-primary">75%</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '75%' }}
              className="h-full bg-primary rounded-full"
            />
          </div>
          <p className="text-[10px] text-slate-500 mt-2">Embedded Systems path</p>
        </div>
      </div>
    </aside>
  );
};

// --- Pages ---

const HomePage = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  
  useEffect(() => {
    fetch('/api/posts').then(res => res.json()).then(setPosts);
  }, []);

  const featuredPost = posts[0];
  const recentPosts = posts.slice(1);

  return (
    <div className="pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Hero Section */}
        {featuredPost && (
          <section className="mb-20">
            <div className="relative rounded-3xl overflow-hidden aspect-[21/9] group">
              <img 
                src={featuredPost.image_url} 
                alt={featuredPost.title} 
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-background-dark/40 to-transparent" />
              <div className="absolute bottom-0 left-0 p-8 md:p-12 max-w-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-primary px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">Featured Insight</span>
                  <span className="text-slate-300 text-xs">12 min read</span>
                </div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">{featuredPost.title}</h1>
                <p className="text-slate-300 text-lg mb-8 line-clamp-2">{featuredPost.content}</p>
                <Link 
                  to={`/post/${featuredPost.id}`}
                  className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-primary/20"
                >
                  Read Full Story <ArrowRight className="size-4" />
                </Link>
              </div>
            </div>
          </section>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Recent Articles */}
          <div className="lg:col-span-2 space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Recent Articles</h2>
              <Link to="/feed" className="text-primary text-sm font-bold hover:underline">View all</Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recentPosts.map(post => (
                <motion.div 
                  key={post.id}
                  whileHover={{ y: -5 }}
                  className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden group"
                >
                  <div className="aspect-video overflow-hidden">
                    <img 
                      src={post.image_url} 
                      alt={post.title} 
                      className="w-full h-full object-cover transition-transform group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-primary text-[10px] font-bold uppercase tracking-widest mb-2 block">{post.category}</span>
                    <h3 className="text-lg font-bold mb-3 group-hover:text-primary transition-colors">{post.title}</h3>
                    <p className="text-slate-400 text-sm line-clamp-2 mb-4">{post.content}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 text-xs">{format(new Date(post.created_at), 'MMM d, yyyy')}</span>
                      <Link to={`/post/${post.id}`} className="text-primary text-sm font-bold flex items-center gap-1">
                        Read <ChevronRight className="size-4" />
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-12">
            {/* Student POV */}
            <section className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
              <h2 className="text-xl font-bold mb-6">Student POV</h2>
              <div className="space-y-6">
                {[
                  { name: "Marcus Chen", quote: "The internship at the robotics lab changed my perspective on hardware-software co-design.", avatar: "https://picsum.photos/seed/marcus/50/50" },
                  { name: "Sarah Jenkins", quote: "Quantum computing isn't just theory anymore; we're seeing real-world CPE applications.", avatar: "https://picsum.photos/seed/sarah/50/50" }
                ].map((pov, i) => (
                  <div key={i} className="flex gap-4">
                    <img src={pov.avatar} alt={pov.name} className="size-10 rounded-full border border-primary/20" referrerPolicy="no-referrer" />
                    <div>
                      <p className="text-slate-300 text-sm italic mb-2">"{pov.quote}"</p>
                      <p className="text-xs font-bold text-primary">{pov.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Newsletter */}
            <section className="bg-primary/10 border border-primary/20 rounded-3xl p-8">
              <h2 className="text-xl font-bold mb-2">Join the Lab</h2>
              <p className="text-slate-400 text-sm mb-6">Get the latest technical insights delivered to your inbox.</p>
              <div className="space-y-3">
                <input 
                  type="email" 
                  placeholder="your@email.com" 
                  className="w-full bg-background-dark border border-slate-700 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-xl transition-all">
                  Subscribe
                </button>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </div>
  );
};

const DiscoveryFeed = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState('For You');

  useEffect(() => {
    fetch('/api/posts').then(res => res.json()).then(setPosts);
  }, []);

  const tabs = ['For You', 'AI & ML', 'Robotics', 'Web3 & Crypto', 'Hardware'];

  return (
    <div className="pt-24 pb-20 flex max-w-7xl mx-auto px-6 gap-12">
      <Sidebar />
      
      <main className="flex-1">
        <div className="mb-10 overflow-x-auto">
          <div className="flex gap-8 border-b border-slate-800">
            {tabs.map(tab => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "pb-4 text-sm font-bold transition-all relative",
                  activeTab === tab ? "text-primary" : "text-slate-500 hover:text-slate-300"
                )}
              >
                {tab}
                {activeTab === tab && (
                  <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
                )}
              </button>
            ))}
          </div>
        </div>

        <section className="mb-12">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="text-primary size-5" />
            <h2 className="text-xl font-bold">Recommended for You</h2>
          </div>
          
          {posts.length > 0 && (
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl overflow-hidden flex flex-col md:flex-row group">
              <div className="md:w-1/2 aspect-video md:aspect-auto overflow-hidden">
                <img 
                  src={posts[0].image_url} 
                  alt={posts[0].title} 
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="md:w-1/2 p-8 flex flex-col justify-center">
                <span className="text-primary text-[10px] font-bold uppercase tracking-widest mb-3 block">Featured</span>
                <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition-colors">{posts[0].title}</h3>
                <p className="text-slate-400 text-sm mb-6 line-clamp-3">{posts[0].content}</p>
                <div className="flex items-center justify-between mt-auto">
                  <div className="flex items-center gap-2">
                    <div className="size-6 rounded-full bg-slate-800 overflow-hidden">
                      <img src={`https://picsum.photos/seed/${posts[0].author}/50/50`} alt={posts[0].author} referrerPolicy="no-referrer" />
                    </div>
                    <span className="text-xs text-slate-500">By {posts[0].author}</span>
                  </div>
                  <Link 
                    to={`/post/${posts[0].id}`}
                    className="bg-primary text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-primary/90 transition-all"
                  >
                    Read Story
                  </Link>
                </div>
              </div>
            </div>
          )}
        </section>

        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold">Tailored Engineering Insights</h2>
            <button className="text-primary text-sm font-bold flex items-center gap-1 hover:underline">
              Refine interests <Settings className="size-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {posts.map(post => (
              <motion.div 
                key={post.id}
                whileHover={{ y: -5 }}
                className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden group flex flex-col"
              >
                <div className="aspect-video overflow-hidden relative">
                  <img 
                    src={post.image_url} 
                    alt={post.title} 
                    className="w-full h-full object-cover transition-transform group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <button className="absolute top-4 right-4 p-2 bg-background-dark/50 backdrop-blur-md rounded-full text-white hover:text-primary transition-colors">
                    <Bookmark className="size-4" />
                  </button>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <span className="text-primary text-[10px] font-bold uppercase tracking-widest mb-2 block">{post.category}</span>
                  <h4 className="text-lg font-bold mb-3 group-hover:text-primary transition-colors">{post.title}</h4>
                  <p className="text-slate-400 text-sm line-clamp-2 mb-6">{post.content}</p>
                  <div className="mt-auto pt-4 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider">{format(new Date(post.created_at), 'MMM d')} • 10 min read</span>
                    <ArrowRight className="size-4 text-primary opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Feedback Widget */}
        <div className="mt-16 bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-lg font-bold mb-1">Help us improve your feed</h4>
            <p className="text-sm text-slate-400">Are these articles relevant to your current projects?</p>
          </div>
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-primary transition-all text-sm font-bold">
              <CheckCircle2 className="size-4 text-emerald-500" /> Yes
            </button>
            <button className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-primary transition-all text-sm font-bold">
              <X className="size-4 text-rose-500" /> Not quite
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

const PostView = () => {
  const id = useLocation().pathname.split('/').slice(-1)[0];
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    fetch(`/api/posts/${id}`).then(res => res.json()).then(setPost);
    fetch(`/api/posts/${id}/comments`).then(res => res.json()).then(setComments);

    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress((window.scrollY / totalHeight) * 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [id]);

  const handleSubmitComment = async () => {
    if (!newComment.trim()) return;
    const res = await fetch(`/api/posts/${id}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        author: 'Alex Rivers', 
        designation: 'CPE Junior Member', 
        content: newComment 
      })
    });
    if (res.ok) {
      setNewComment('');
      fetch(`/api/posts/${id}/comments`).then(res => res.json()).then(setComments);
    }
  };

  if (!post) return null;

  return (
    <div className="pt-24 pb-20">
      {/* Reading Progress Bar */}
      <div className="fixed top-[72px] left-0 right-0 z-50 h-1 bg-slate-800">
        <motion.div 
          className="h-full bg-primary"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <article className="max-w-3xl mx-auto px-6">
        <header className="mb-12">
          <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-widest mb-4">
            <Tag className="size-3" />
            <span>{post.category}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">{post.title}</h1>
          <div className="flex items-center gap-6 text-slate-400 text-sm">
            <div className="flex items-center gap-2">
              <div className="size-8 rounded-full bg-primary/20 flex items-center justify-center">
                <Users className="size-4 text-primary" />
              </div>
              <span className="font-medium text-slate-200">{post.author}</span>
            </div>
            <span>•</span>
            <span>8 min read</span>
            <span>•</span>
            <span>{format(new Date(post.created_at), 'MMM d, yyyy')}</span>
          </div>
        </header>

        <div className="rounded-3xl overflow-hidden mb-12 aspect-video">
          <img src={post.image_url} alt={post.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>

        <div className="markdown-body">
          <ReactMarkdown>{post.content}</ReactMarkdown>
        </div>

        <div className="flex items-center justify-between py-8 border-y border-slate-800 my-16">
          <div className="flex gap-6">
            <button className="flex items-center gap-2 text-slate-400 hover:text-primary transition-colors">
              <Heart className="size-5" />
              <span className="font-bold">124</span>
            </button>
            <button className="flex items-center gap-2 text-slate-400 hover:text-primary transition-colors">
              <MessageSquare className="size-5" />
              <span className="font-bold">{comments.length} Comments</span>
            </button>
          </div>
          <div className="flex gap-3">
            <button className="p-2 rounded-full text-slate-400 hover:bg-primary/10 hover:text-primary transition-all">
              <Share2 className="size-5" />
            </button>
            <button className="p-2 rounded-full text-slate-400 hover:bg-primary/10 hover:text-primary transition-all">
              <Bookmark className="size-5" />
            </button>
          </div>
        </div>

        {/* Feedback Section */}
        <section className="space-y-10">
          <div>
            <h3 className="text-2xl font-bold mb-2">Student Feedback</h3>
            <p className="text-slate-400 text-sm">Share your thoughts on the quantum leap with your peers.</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 flex gap-4">
            <div className="size-10 rounded-full bg-primary flex items-center justify-center text-white shrink-0">
              <Edit3 className="size-5" />
            </div>
            <div className="flex-1 space-y-4">
              <textarea 
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add your insight or ask a question..."
                className="w-full bg-background-dark border border-slate-700 rounded-xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary min-h-[120px]"
              />
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500 italic">Posting as Computer Engineering Student</span>
                <button 
                  onClick={handleSubmitComment}
                  className="bg-primary hover:bg-primary/90 text-white px-8 py-2.5 rounded-xl font-bold transition-all"
                >
                  Post Comment
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {comments.map(comment => (
              <div key={comment.id} className="flex gap-4">
                <div className="size-10 rounded-full bg-slate-800 overflow-hidden shrink-0">
                  <img src={`https://picsum.photos/seed/${comment.author}/50/50`} alt={comment.author} referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-bold text-sm">{comment.author} <span className="text-xs font-normal text-slate-500 ml-2">{comment.designation}</span></h4>
                    <span className="text-xs text-slate-500">{format(new Date(comment.created_at), 'h:mm a')}</span>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed">{comment.content}</p>
                  <div className="flex gap-4 mt-3">
                    <button className="text-xs font-bold text-primary hover:underline">Reply</button>
                    <button className="text-xs font-bold text-primary hover:underline">Helpful</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </article>
    </div>
  );
};

const AdminDashboard = () => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/stats').then(res => res.json()).then(setStats);
    fetch('/api/posts').then(res => res.json()).then(setPosts);
  }, []);

  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-6 flex gap-12">
      <aside className="w-64 hidden lg:flex flex-col gap-2 border-r border-slate-800 p-6 sticky top-24 h-[calc(100vh-6rem)]">
        {[
          { icon: LayoutDashboard, label: 'Dashboard', active: true },
          { icon: FileText, label: 'Posts' },
          { icon: Users, label: 'Authors' },
          { icon: BarChart3, label: 'Analytics' },
        ].map((item, i) => (
          <button 
            key={i}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
              item.active ? "bg-primary text-white" : "text-slate-400 hover:bg-slate-800/50 hover:text-white"
            )}
          >
            <item.icon className="size-5" />
            <span className="text-sm font-medium">{item.label}</span>
          </button>
        ))}
      </aside>

      <main className="flex-1 space-y-10">
        <div className="flex items-end justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-slate-400 text-sm">Welcome back, Admin. Here's what's happening today.</p>
          </div>
          <button 
            onClick={() => navigate('/admin/editor')}
            className="bg-primary hover:bg-primary/90 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-primary/20"
          >
            <Plus className="size-5" /> New Post
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {[
            { label: 'Total Posts', value: stats?.posts, icon: FileText, color: 'text-blue-500' },
            { label: 'Total Views', value: stats?.views, icon: Eye, color: 'text-emerald-500' },
            { label: 'Comments', value: stats?.comments, icon: MessageSquare, color: 'text-amber-500' },
            { label: 'Subscribers', value: stats?.subscribers, icon: Users, color: 'text-purple-500' },
          ].map((stat, i) => (
            <div key={i} className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={cn("p-2 rounded-xl bg-slate-800", stat.color)}>
                  <stat.icon className="size-5" />
                </div>
                <span className="text-xs font-bold text-emerald-500">+12%</span>
              </div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">{stat.label}</p>
              <h3 className="text-2xl font-bold">{stat.value?.toLocaleString() || '0'}</h3>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Recent Posts Table */}
          <div className="xl:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-bold">Recent Blog Posts</h3>
              <button className="text-primary text-xs font-bold hover:underline">View all</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Author</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Views</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {posts.map(post => (
                    <tr key={post.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-sm font-bold truncate max-w-[200px]">{post.title}</p>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">{post.author}</td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
                          post.status === 'Published' ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"
                        )}>
                          {post.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">{post.views}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-2 text-slate-400 hover:text-primary transition-colors"><Edit3 className="size-4" /></button>
                          <button className="p-2 text-slate-400 hover:text-rose-500 transition-colors"><Trash2 className="size-4" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Draft */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6">
            <h3 className="font-bold mb-6">Quick Draft</h3>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Post Title" 
                className="w-full bg-background-dark border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <textarea 
                placeholder="What's on your mind?" 
                className="w-full bg-background-dark border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary min-h-[150px]"
              />
              <button className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-all">
                Save Draft
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const AdminEditor = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('AI & ML');
  const [status, setStatus] = useState('Draft');
  const navigate = useNavigate();

  const handlePublish = async () => {
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        content,
        author: 'Admin',
        category,
        status: 'Published',
        image_url: 'https://picsum.photos/seed/newpost/1200/600'
      })
    });
    if (res.ok) navigate('/admin');
  };

  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-6">
      <div className="flex items-end justify-between mb-10">
        <div>
          <div className="flex items-center gap-2 text-primary mb-1">
            <Edit3 className="size-4" />
            <span className="text-xs font-bold uppercase tracking-widest">Post Management</span>
          </div>
          <h1 className="text-3xl font-bold">Manage Post</h1>
          <p className="text-slate-400 text-sm mt-1">Compose and configure your technical blog post.</p>
        </div>
        <div className="flex items-center gap-4">
          <button className="px-6 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold hover:bg-slate-800 transition-all">
            Save Draft
          </button>
          <button 
            onClick={handlePublish}
            className="bg-primary hover:bg-primary/90 text-white px-8 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-primary/20"
          >
            Publish Post
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 space-y-8">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Post Title</label>
              <input 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                type="text" 
                placeholder="e.g., Implementing Neural Networks in C++" 
                className="w-full bg-background-dark border border-slate-800 rounded-xl px-6 py-4 text-xl font-bold focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Content</label>
              <div className="border border-slate-800 rounded-2xl overflow-hidden">
                <div className="bg-slate-800/50 p-2 border-b border-slate-800 flex gap-2">
                  <button className="p-2 hover:bg-slate-700 rounded-lg text-slate-400"><Edit3 className="size-4" /></button>
                  <button className="p-2 hover:bg-slate-700 rounded-lg text-slate-400"><ImageIcon className="size-4" /></button>
                  <button className="p-2 hover:bg-slate-700 rounded-lg text-slate-400"><Tag className="size-4" /></button>
                </div>
                <textarea 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Start writing your technical breakdown here..."
                  className="w-full bg-background-dark p-6 text-slate-300 leading-relaxed min-h-[400px] focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 block">Featured Image</label>
            <div className="border-2 border-dashed border-slate-800 rounded-2xl p-12 flex flex-col items-center justify-center gap-4 hover:border-primary/50 transition-all cursor-pointer group">
              <div className="size-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-500 group-hover:text-primary transition-colors">
                <ImageIcon className="size-8" />
              </div>
              <div className="text-center">
                <p className="font-bold">Click to upload or drag and drop</p>
                <p className="text-slate-500 text-xs mt-1">SVG, PNG, JPG or WebP (max. 5MB)</p>
              </div>
            </div>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 space-y-8">
            <h3 className="font-bold flex items-center gap-2 border-b border-slate-800 pb-4">
              <Settings className="size-4 text-primary" /> Post Settings
            </h3>
            
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Visibility</label>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setStatus('Published')}
                  className={cn(
                    "flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all",
                    status === 'Published' ? "bg-primary text-white" : "bg-slate-800 text-slate-400"
                  )}
                >
                  <Globe className="size-3" /> Public
                </button>
                <button 
                  onClick={() => setStatus('Draft')}
                  className={cn(
                    "flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all",
                    status === 'Draft' ? "bg-primary text-white" : "bg-slate-800 text-slate-400"
                  )}
                >
                  <Lock className="size-3" /> Draft
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Category</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-background-dark border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option>AI & ML</option>
                <option>Robotics</option>
                <option>Web3 & Crypto</option>
                <option>Hardware</option>
                <option>Quantum Computing</option>
              </select>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Schedule</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 size-4" />
                <input 
                  type="datetime-local" 
                  className="w-full bg-background-dark border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 space-y-6">
            <h3 className="font-bold flex items-center gap-2 border-b border-slate-800 pb-4">
              <Tag className="size-4 text-primary" /> Tags
            </h3>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Add a tag..." 
                className="w-full bg-background-dark border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="flex flex-wrap gap-2">
                {['PyTorch', 'NVIDIA Jetson', 'C++'].map(tag => (
                  <span key={tag} className="bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-2">
                    {tag} <X className="size-3 cursor-pointer" />
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary/20 to-transparent border border-primary/20 rounded-3xl p-8 text-center space-y-4">
            <div className="size-12 bg-primary/20 rounded-2xl mx-auto flex items-center justify-center text-primary">
              <Eye className="size-6" />
            </div>
            <div>
              <h4 className="font-bold">Preview Post</h4>
              <p className="text-slate-400 text-xs mt-1">See how your post looks to the public.</p>
            </div>
            <button className="w-full py-2.5 rounded-xl border border-primary/40 text-primary font-bold hover:bg-primary hover:text-white transition-all">
              Open Preview
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
};

const Footer = () => (
  <footer className="bg-slate-900 border-t border-slate-800 py-16">
    <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
      <div className="col-span-1 md:col-span-2">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-primary p-1.5 rounded-lg">
            <Rss className="text-white size-5" />
          </div>
          <span className="text-xl font-bold tracking-tight">UDD-CPE Blog</span>
        </div>
        <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
          The official engineering blog for the Computer Engineering department at Universidad de Dagupan. Empowering students through technical excellence.
        </p>
      </div>
      <div>
        <h4 className="font-bold mb-6">Resources</h4>
        <ul className="space-y-4 text-sm text-slate-400">
          <li><Link to="/courses" className="hover:text-primary transition-colors">Courses</Link></li>
          <li><Link to="/research" className="hover:text-primary transition-colors">Research</Link></li>
          <li><Link to="/faculty" className="hover:text-primary transition-colors">Faculty</Link></li>
          <li><Link to="/guidelines" className="hover:text-primary transition-colors">Guidelines</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="font-bold mb-6">Support</h4>
        <ul className="space-y-4 text-sm text-slate-400">
          <li><Link to="/help" className="hover:text-primary transition-colors">Help Center</Link></li>
          <li><Link to="/api" className="hover:text-primary transition-colors">API Docs</Link></li>
          <li><Link to="/status" className="hover:text-primary transition-colors">System Status</Link></li>
          <li><Link to="/feedback" className="hover:text-primary transition-colors">Feedback</Link></li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
      <p className="text-slate-500 text-xs">© 2024 UDD Computer Engineering Department. All rights reserved.</p>
      <div className="flex gap-6 text-slate-500 text-xs">
        <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/feed" element={<DiscoveryFeed />} />
            <Route path="/post/:id" element={<PostView />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/editor" element={<AdminEditor />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}
