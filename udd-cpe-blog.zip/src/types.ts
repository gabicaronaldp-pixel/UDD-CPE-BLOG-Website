import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface Post {
  id: number;
  title: string;
  content: string;
  author: string;
  category: string;
  status: string;
  views: number;
  created_at: string;
  image_url: string;
}

export interface Comment {
  id: number;
  post_id: number;
  author: string;
  designation: string;
  content: string;
  created_at: string;
}

export interface Stats {
  posts: number;
  views: number;
  comments: number;
  subscribers: number;
}
